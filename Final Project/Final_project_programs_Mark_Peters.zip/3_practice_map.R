gg <- ggplot(World, aes(HPI, inequality, fill=income_grp, size= gdp_cap_est))+
  geom_point(alpha=0.5, shape=21, color="black")+

  scale_size(range = c(.1, 24), name="GDP")+
  
  scale_fill_viridis(discrete=TRUE, guide=FALSE, option="A") +
  theme_ipsum() +
  theme(legend.position="bottom") +
  ylab("National Inequality") +
  xlab("HPI (Happiness Index)") +
  theme(legend.position = "none")+
  
  labs(title="Inequality Vs HPI", subtitle="indexed by GDP & Income group")

