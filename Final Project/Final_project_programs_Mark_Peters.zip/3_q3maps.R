library(tmap)
data("World")

tmap_mode("view")

tm_shape(World)+
  tm_polygons("life_exp")

##################################

tm_shape(World) +
  tm_polygons(c("HPI", "economy")) +
  tm_facets(sync = TRUE, ncol = 2)
