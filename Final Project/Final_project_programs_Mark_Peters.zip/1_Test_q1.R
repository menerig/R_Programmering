## Test program for Q1

minimum <- function(x){
  min <- x[1]
  for (i in 2:length(x)) {
    if(x[i]< min)
      min <- x[i]
  }
  return(min)
}

maximum <- function(x){
  max <- x[1]
  for (i in 2:length(x)) {
    if(x[i]> max)
      max <- x[i]
  }
  return(max)
}

mean_me <- function(x){
  sum <- x[1]
  for (i in 2:length(x)) {
    sum <- sum + x[i]
  }
  mean_me <- sum/length(x)
  return(mean_me)
}

## use sample to generate numbers for testing
vec1 <- sample(20:30, 30, replace= TRUE)
vec2 <- sample(15:28, 30, replace= TRUE)
vec3 <- sample(26:36, 30, replace= TRUE)
df_me <- data.frame(vec1, vec2, vec3)

for (i in 1:3) {
  maxi <- maximum(df_me[ ,i])
  cat(paste("\nThe maximum value in column",i,"is",maxi,"\n"))
  mini <- minimum(df_me[ ,i])
  cat(paste("\nThe minimum value in column",i,"is",mini,"\n"))
  meani <- mean_me(df_me[ ,i])
  cat(paste("\nThe mean value for column",i,"is", meani,"\n"))
}

for (i in 1:3) {
  maxi <- max(df_me[ ,i])
  cat(paste("\nThe R maximum value in column",i,"is",maxi,"\n"))
  mini <- min(df_me[ ,i])
  cat(paste("\nThe R minimum value in column",i,"is",mini,"\n"))
  meani <- mean(df_me[ ,i])
  cat(paste("\nThe R mean value for column",i,"is", meani,"\n"))
}
