## create a plot from the 'World' dataframe with HPI for the x axis and inequality for the y.
## Income is shown by colour and GPD by circle size.
gg2 <- ggplot(World, aes(HPI, inequality, col= income_grp, size= gdp_cap_est))+
 
## Alpha grades the transparency.Scale size creates a more visually arresting 'bubble' 
  geom_point(alpha=0.5)+
  scale_size(range = c(.1, 24), name="GDP estimate")+

## Here are all the labels for the plot
labs(title="Inequality Vs HPI", subtitle="indexed by GDP and Income Group", 
     x="HPI (Happiness Index)",
    caption="World Demographics")

