## create plot using economy as the x and happiness as the y, the fill was economy as well
gg3 <- ggplot(World, aes(x=economy, y=HPI, fill=economy)) + 
  
## call the boxplot through the geom function
  geom_boxplot()+
  labs(title="Happiness of Economic groups")+
xlab("Economic Group") +
  ## there is no legend so that the whole plot could fit on the page
  theme(legend.position="none") +
  xlab("")