tmap_mode("plot")

tm_shape(World)+
  tm_polygons("economy")
